import HeroSection from '@/components/HeroSection';
import ServiceDashboard from '@/components/ServiceDashboard';
import SystemStats from '@/components/SystemStats';
import AdminTools from '@/components/AdminTools';
import ProjectsSection from '@/components/ProjectsSection';
import AISidePanel from '@/components/AISidePanel';
import AuthButton from '@/components/AuthButton';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-background scanlines">
      {/* Grid background overlay */}
      <div className="fixed inset-0 grid-bg opacity-20 pointer-events-none" />
      
      {/* Auth button */}
      <AuthButton />
      
      <main className="relative z-10">
        <HeroSection />
        <ServiceDashboard />
        <SystemStats />
        <AdminTools />
        <ProjectsSection />
        <Footer />
      </main>

      <AISidePanel />
    </div>
  );
};

export default Index;
