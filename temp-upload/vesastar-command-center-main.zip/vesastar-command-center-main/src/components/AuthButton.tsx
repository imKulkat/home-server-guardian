import { useState } from 'react';
import { User, LogOut } from 'lucide-react';
import { useAuth } from './AuthProvider';
import LoginModal from './LoginModal';

const AuthButton = () => {
  const [showLogin, setShowLogin] = useState(false);
  const { isAuthenticated, isOwner, logout } = useAuth();

  if (isAuthenticated && isOwner) {
    return (
      <div className="fixed top-4 right-4 z-40 flex items-center gap-3">
        <div className="cyber-card rounded-full px-4 py-2 flex items-center gap-2 border border-success/30">
          <span className="w-2 h-2 rounded-full bg-success status-online" />
          <span className="text-sm text-success">Owner Access</span>
        </div>
        <button
          onClick={logout}
          className="cyber-card rounded-full p-2.5 border border-primary/30 hover:border-destructive/50 hover:text-destructive transition-all group"
          title="Sign Out"
        >
          <LogOut className="w-4 h-4 text-muted-foreground group-hover:text-destructive" />
        </button>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setShowLogin(true)}
        className="fixed top-4 right-4 z-40 cyber-card rounded-full px-4 py-2 flex items-center gap-2 border border-primary/30 hover:border-primary/50 transition-all group"
      >
        <User className="w-4 h-4 text-primary" />
        <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
          Sign In
        </span>
      </button>

      <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
    </>
  );
};

export default AuthButton;
