import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  isOwner: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Hardcoded owner credentials (front-end only - NOT secure for production)
const OWNER_USERNAME = 'Kulkat11';
const OWNER_PASSWORD = '1mKulkat!';

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('vesastar_auth');
    if (stored === 'owner') {
      setIsAuthenticated(true);
      setIsOwner(true);
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    if (username === OWNER_USERNAME && password === OWNER_PASSWORD) {
      setIsAuthenticated(true);
      setIsOwner(true);
      localStorage.setItem('vesastar_auth', 'owner');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setIsOwner(false);
    localStorage.removeItem('vesastar_auth');
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, isOwner, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
