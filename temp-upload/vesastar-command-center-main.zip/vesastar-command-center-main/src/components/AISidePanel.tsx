import { useState } from 'react';
import { Bot, X, Maximize2, Minimize2 } from 'lucide-react';

const AISidePanel = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
      {/* Floating trigger button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 group"
          aria-label="Open AI Assistant"
        >
          <div className="relative">
            {/* Outer glow ring */}
            <div className="absolute inset-0 rounded-full bg-primary/30 blur-md group-hover:bg-primary/50 transition-all duration-300 scale-110" />
            
            {/* Button */}
            <div className="relative w-14 h-14 rounded-full bg-background border-2 border-primary flex items-center justify-center neon-border group-hover:scale-110 transition-all duration-300 float-animation">
              <Bot className="w-6 h-6 text-primary" />
            </div>

            {/* Tooltip */}
            <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
              <div className="cyber-card rounded-md px-3 py-1.5 whitespace-nowrap text-sm text-foreground border border-primary/30">
                AI Assistant
              </div>
            </div>
          </div>
        </button>
      )}

      {/* Side Panel */}
      <div
        className={`fixed top-0 right-0 h-full z-50 transition-all duration-300 ease-out ${
          isOpen 
            ? isExpanded 
              ? 'w-full md:w-2/3' 
              : 'w-full md:w-[420px]' 
            : 'w-0'
        }`}
      >
        {/* Backdrop for mobile */}
        {isOpen && (
          <div 
            className="fixed inset-0 bg-background/50 backdrop-blur-sm md:hidden"
            onClick={() => setIsOpen(false)}
          />
        )}

        {/* Panel content */}
        <div 
          className={`relative h-full bg-background border-l border-primary/30 flex flex-col transition-transform duration-300 ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-primary/20 bg-card">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10 border border-primary/30">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-foreground">AI Assistant</h3>
                <p className="text-xs text-muted-foreground">OpenWebUI Interface</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-2 rounded-md hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground hidden md:block"
                title={isExpanded ? 'Minimize' : 'Expand'}
              >
                {isExpanded ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-md hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Iframe container */}
          <div className="flex-1 relative">
            {isOpen && (
              <iframe
                src="https://ai.vesastar.top"
                className="absolute inset-0 w-full h-full border-0"
                title="AI Assistant"
                allow="microphone; clipboard-write"
              />
            )}
            
            {/* Loading state */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center text-muted-foreground opacity-50">
                <Bot className="w-12 h-12 mx-auto mb-2 animate-pulse" />
                <p className="text-sm">Loading AI Interface...</p>
              </div>
            </div>
          </div>

          {/* Bottom accent */}
          <div className="h-1 glow-line" />
        </div>
      </div>
    </>
  );
};

export default AISidePanel;
