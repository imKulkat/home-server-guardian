import { useEffect, useState, useRef } from 'react';
import { Cpu, HardDrive, Activity, Wifi, Clock } from 'lucide-react';
import AudioPlayer from './AudioPlayer';

interface StatData {
  cpu: number;
  ram: number;
  disk: number;
  network: { up: number; down: number };
  uptime: string;
}

// Simulated stats that fluctuate realistically
const generateRealisticStats = (prev: StatData): StatData => {
  const fluctuate = (value: number, min: number, max: number, volatility: number = 5) => {
    const change = (Math.random() - 0.5) * volatility * 2;
    return Math.min(max, Math.max(min, value + change));
  };

  return {
    cpu: Math.round(fluctuate(prev.cpu, 8, 65, 3)),
    ram: Math.round(fluctuate(prev.ram, 40, 78, 2)),
    disk: Math.round(fluctuate(prev.disk, 60, 75, 0.5)),
    network: {
      up: Math.round(fluctuate(prev.network.up, 5, 80, 8)),
      down: Math.round(fluctuate(prev.network.down, 20, 350, 15)),
    },
    uptime: prev.uptime, // Uptime stays consistent
  };
};

const calculateUptime = (startTime: number): string => {
  const now = Date.now();
  const diff = now - startTime;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${days}d ${hours}h ${minutes}m`;
};

const StatBar = ({ label, value, icon: Icon }: { label: string; value: number; icon: typeof Cpu }) => {
  const [displayValue, setDisplayValue] = useState(value);

  useEffect(() => {
    // Smooth transition animation
    const step = (value - displayValue) / 10;
    if (Math.abs(step) < 0.5) {
      setDisplayValue(value);
      return;
    }
    const timer = setTimeout(() => {
      setDisplayValue(prev => prev + step);
    }, 30);
    return () => clearTimeout(timer);
  }, [value, displayValue]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Icon className="w-4 h-4 text-primary" />
          <span>{label}</span>
        </div>
        <span className="text-primary font-medium tabular-nums">{Math.round(displayValue)}%</span>
      </div>
      <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
        <div
          className="h-full bg-primary progress-glow rounded-full transition-all duration-500 ease-out"
          style={{ width: `${displayValue}%` }}
        />
      </div>
    </div>
  );
};

const SystemStats = () => {
  const startTimeRef = useRef(Date.now() - (14 * 24 * 60 * 60 * 1000 + 7 * 60 * 60 * 1000)); // ~14 days ago
  const [stats, setStats] = useState<StatData>({
    cpu: 25,
    ram: 58,
    disk: 67,
    network: { up: 35, down: 120 },
    uptime: calculateUptime(startTimeRef.current),
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        ...generateRealisticStats(prev),
        uptime: calculateUptime(startTimeRef.current),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="px-4 py-16">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-primary/30" />
          <h2 className="text-sm uppercase tracking-[0.3em] text-primary">
            System Status
          </h2>
          <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-primary/30" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main stats panel */}
          <div className="lg:col-span-2 cyber-card rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* CPU */}
              <StatBar label="CPU Load" value={stats.cpu} icon={Cpu} />

              {/* RAM */}
              <StatBar label="RAM Usage" value={stats.ram} icon={Activity} />

              {/* Disk */}
              <StatBar label="Disk Space" value={stats.disk} icon={HardDrive} />

              {/* Network & Uptime */}
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Wifi className="w-4 h-4 text-primary" />
                    <span>Network</span>
                  </div>
                  <div className="text-right">
                    <span className="text-success text-xs">↑ {stats.network.up}</span>
                    <span className="text-muted-foreground mx-1">/</span>
                    <span className="text-primary text-xs">↓ {stats.network.down}</span>
                    <span className="text-muted-foreground text-xs ml-1">Mb/s</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4 text-primary" />
                    <span>Uptime</span>
                  </div>
                  <span className="text-primary font-medium tabular-nums">{stats.uptime}</span>
                </div>
              </div>
            </div>

            {/* Data flow indicator */}
            <div className="mt-6 pt-4 border-t border-primary/10">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="w-2 h-2 rounded-full bg-success status-online" />
                <span>All systems operational</span>
                <span className="ml-auto tabular-nums">Refresh: 2s</span>
              </div>
            </div>
          </div>

          {/* Audio Player */}
          <AudioPlayer />
        </div>
      </div>
    </section>
  );
};

export default SystemStats;
